/*
Assignment 5
CSCI 340
Name: Lukus Hendrix
ZID: z1761354
SECTION: 1
Due Date: 03/10/2017
T.A: Jyostna Ankam

FUNCTION:  This is the header file for the tree traversal that defines
	the classes inside public, private, using one friend to link
	the binTree with the Node class.


INPUT:     No input.

*/



#ifndef ASSIGNMENT5
#define ASSIGNMENT5

using namespace std;

class binTree;
//class BST;

class  Node {

int data;
Node* left;
Node* right;

public:

friend class binTree;
friend class BST;

Node(int d)
{
        data = d;
        left = nullptr;
        right = nullptr;
}

};

class binTree {


    public:
        binTree();
        virtual void insert( int );
        int height() const;
        unsigned size() const;
        void inorder( void(*)(int) );
        void preorder( void(*)(int) );
        void postorder( void(*)(int) );

    protected:
        Node* root;

    private:
        void insert( Node*&, int );
        int height( Node* ) const;
        unsigned int size( Node* ) const;
        void inorder( Node*, void(*)(int) );
        void preorder( Node*, void(*)(int) );
        void postorder( Node*, void(*)(int) );
};





#endif

