/*
Assignment 6
CSCI 340
Name: Lukus Hendrix
ZID: z1761354
SECTION: 1
Due Date: 3/28/2017
T.A: Jyostna Ankam

FUNCTION:  This program implements a derived class to represent a binary search
	tree. This program searches for a  number between a high and a low count
	of integers which in this case high would be 30 and low would be 20.
	The range of random numbers will be between 1 and 1000. This function
	compares the left value with the right value. The left value is always
	going to be less than the right value.

INPUT:     The input is controlled inside of the assignment6main file and sets
	the low range as 20 and the high range to 30. These integers are
	calculated from a random number range from 1 to 1000.

OUTPUT:   The output displays the tree's height , size, an in order traverse,
	a preorder traverse, and a post order traverse for the random numbers
	calculated with the input above.
*/


#include <iostream>
#include "assignment5.h"
#include "assignment6.h"
using namespace std;


/****************************************************************

   FUNCTION:   void BST::insert(int val)

   ARGUMENTS:  int val

   RETURNS:    Nothing, void

   NOTES:      This function is the public insert function that
	calls its private function with the root recursivly.

****************************************************************/
void BST::insert(int val)
{
	insert(root, val);
}


/****************************************************************

   FUNCTION:   bool BST::search(int sVal)

   ARGUMENTS:  int sVal

   RETURNS:    search(root, sVal)

   NOTES:      This function is the public search function that
        calls its private function with the root recursivly.

****************************************************************/

bool BST::search(int sVal)
{
	return search(root, sVal);


}


/****************************************************************

   FUNCTION:  int BST::sumOfRange(const int lower, const int upper)

   ARGUMENTS: const int lower, const int upper

   RETURNS:   sumOfRange(root, lower, upper);

   NOTES:      This function is the public sumOfRange function that
        calls its private function with the root recursivly.

****************************************************************/


int BST::sumOfRange(const int lower, const int upper)
{
	return sumOfRange(root, lower, upper);

}


/****************************************************************

   FUNCTION: bool BST::remove(int val)

   ARGUMENTS: int val

   RETURNS:  remove(root, val);

   NOTES:      This function is the public remove function that
        calls its private function with the root recursivly.

****************************************************************/

bool BST::remove(int val)
{
	return remove(root, val);
}


/****************************************************************

   FUNCTION:   void BST::insert(Node* &ptr, int val)

   ARGUMENTS:  Node* &ptr, int val

   RETURNS:    Nothing, void

   NOTES:      This function is the private insert function thet
	uses a ptr to insert each new Node in the tree. If the
	ptr is equal to a nullptr then it inserts a new node value
	to become the starting root. Otherwise, if the values to
	be inserted is less the data in the root or parent it
	will insert the value on the left side of the root. If
	the value is greater than the root or parent it will
	insert the value on the right side of the root.

****************************************************************/

void BST::insert(Node* &ptr, int val)
{
	if(ptr == nullptr)
		ptr= new Node(val);
	else
	{
		if(val < ptr->data)
			insert(ptr->left, val);
		else
			insert(ptr->right, val);
	}

}

/****************************************************************

   FUNCTION:  bool BST::search(Node* &ptr, int val)

   ARGUMENTS: Node* &ptr, int val

   RETURNS:    True or False

   NOTES:      This function is the private search method. This
	method searches the tree for the input value. If there is
	no root because the ptr is equal to a nullptr then it
	returns false, indicating to the program that there is no
	root of the tree available. If the searched value is less
	then the data being pointed to then the search method
	is then called recursivly to the left side of the tree.
	Otherwise, if the searched value is greater then the
	root or parent the seach method is returned and called
	recursivly to the right side of the tree. Once the value
	is found the value will equal to the data ptr is pointing
	to and return true.

****************************************************************/

bool BST::search(Node* &ptr, int val)
{
	if(ptr == nullptr)
		return false;



		if (val < ptr-> data )
			return search(ptr->left, val);
		else if(val > ptr-> data)
			return search(ptr-> right, val);
		else if(val == ptr->data)
			return true;


	return false;
}


/****************************************************************

   FUNCTION: int BST::sumOfRange(Node* &ptr, const int lower, const int upper)

   ARGUMENTS: Node* &ptr, const int lower, const int upper

   RETURNS:   ptr->data + sumOfRange(ptr->left, lower , upper ) + sumOfRange(ptr->right, lower, upper)
	OR sumOfRange(ptr->left, lower, upper) + sumOfRange(ptr->right, lower, upper)

   NOTES:    This function calculates the sum of the range by
	adding the left and right nodes of the tree which are
	between the lower and upper input values. If the pointer
	is equal to a nullptr then its returns 0; Otherwise, if
	the input data is greater or equal to lower and less or
	equal to upper it adds the data to the sum of the left
	and right nodes. Otherwise, it just return the sum of the
	left and right nodes.

****************************************************************/

int BST::sumOfRange(Node* &ptr, const int lower, const int upper)
{
	if(ptr == nullptr)
		return 0;

	else if(ptr-> data >= lower && ptr->data <= upper){
	return ptr->data + sumOfRange(ptr->left, lower , upper ) + sumOfRange(ptr->right, lower, upper);}
	else
		return sumOfRange(ptr->left, lower, upper) + sumOfRange(ptr->right, lower, upper);


}

/****************************************************************

   FUNCTION: bool BST::remove(Node* &ptr, int x)

   ARGUMENTS: Node* &ptr, int x

   RETURNS:  True or False

   NOTES:      This function is the private remove funtion. The
	purpose of this function is to iterate through the left
	and right side of the tree and find the intended input
	values to remove. This function also finds the predecessor
	to replace the values that have been removed. Declarations
	of a temperary node and predecessor node are created.
	If the root is a null value, this simply returns false.
	Otherwise, if ptr is greater than x then ptr will
	move one node to the left. If the data of ptr is less
	than x the ptr will move one node to the right. If the
	data in ptr is equal to x then it goes through 4 series
	of data checks. The first is if there is a nullptr on the
	left and right of the ptr then it is concidered a leaf
	which is then assigned a nullptr and deleted then
	returns true. The second checks if there is a nullptr
	on the right and not on the left, if so, it will assign
	the ptr to a temparary node, then assign the left node
	to ptr. The temparary node will then be deleted and it
	will return true..  The third checks if there is a nullptr
        on the left and not on the right, if so, it will assign
        the ptr to a temparary node, then assign the right node
        to ptr. The temparary node will then be deleted and it
        will return true. The last check is to see if there is
	a node on both the right and left side of the ptr. In
	this case the predecessor node will be assigned to the
	left node. The predecessor will then be placed into a
	loop, "while the predecessor is the right node it will
	be assigned to the right node." This is implemented so
	the predecessor can go to the right most leaf. Once the
	loop has stopped the predecessor will be pointing to the
	last node and ptr will assign itself to the predecessor.
	Once finished the predecessor will be removed and ptr will
	be replaced by the predecessors value. The function will
	return true.



****************************************************************/

bool BST::remove(Node* &ptr, int x)
{
	 Node* temp;
	Node* pred;

	if(ptr == nullptr)
		return false;

	else if(ptr -> data > x)
		remove(ptr -> left, x);

	else if(ptr -> data < x)
		remove(ptr -> right, x);

	if(ptr -> data == x )
	{
		if(ptr->left  == nullptr && ptr->right == nullptr)
		{	ptr = nullptr;
			delete ptr;
			return true;
		}
		else if (ptr->left != nullptr && ptr->right == nullptr)
		{
			temp = ptr;
			ptr = ptr->left;
			temp = nullptr;
			delete temp;
			return true;
		}

		else if(ptr-> left == nullptr && ptr->right != nullptr)
		{
			temp = ptr;
			ptr = ptr->right;
			temp = nullptr;
			delete temp;
			return true;
		}
		else if(ptr->left != nullptr && ptr->right != nullptr)
		{
		pred = ptr ->left;
		while(pred -> right)
		{
			pred = pred -> right;
		}
		ptr -> data = pred -> data;
		remove(ptr->left, pred->data);
		return true;
		}
	}
	return true;
}
