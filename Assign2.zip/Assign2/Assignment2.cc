/*
Assignment 2
CSCI 340
Name: Lukus Hendrix
ZID: z1761354
SECTION: 1
Due Date: 2/9/2017
T.A: Jyostna Ankam

  FUNCTION:  This program implements two search algorithms , one linear and
	one binary on randomly generated integers sorted in vectors. This
	program utilizese the random number generator called rand(), the
	find function called find(), the equal range function, the sort()
	function and declears a function pointer.

   INPUT:     The input has been provided in the inputVec as DATA_SIZE which
                is defined as 200 random number.

   OUTPUT:   The output displays one 200 random number list and a 100
	random number list to be searched. The is finds the percent of
	successful searches on sorted and unsorted data for the binary
	 and linear search algorithms.

*/


#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <iomanip>

using namespace std;

const int DATA_SIZE = 200;

const int SEARCH_SIZE = 100;

const int DATA_SEED = 7;

const int SEARCH_SEED = 9;

/****************************************************************

   FUNCTION:   void genRndNums( vector<int>& v, int seed )

   ARGUMENTS:   vector<int>& v, int seed

   RETURNS:    Nothing, Void

   NOTES:      This function generates random numbers from 1 to
	200 by implementing a for loop to iterate through the
	vector size. This function uses the seed parameter to
	generate random integers after the "for" loop. The random
	numbers are then calculated by the modulus, first subtracting
	the HIGH integer (200) by the LOW integer (1), then
	using the remander from the modulus for adding  1.
****************************************************************/

void genRndNums( vector<int>& v, int seed ) {

int LOW = 1, HIGH =200 ;

srand (seed); // Srand becomes an integer value

for(int i = 0; i < v.size(); i++) // loop iterates through vector

v[i] = rand() % (HIGH-LOW +1) + LOW; // for index i, HIGH and LOW are subtracted
					// and plus 1 and modulus is used to
					// get the remainder.

}

/****************************************************************

   FUNCTION: int linearSearch( const vector<int>& inputVec, int x)

   ARGUMENTS:   const vector<int>& inputVec, int x

   RETURNS:    integer,  itrate - inputVec.begin() or -1

   NOTES:  This function implements a linear search. It starts
	by declaring a vector constant iterator named itrate.
	Next the function uses the find() function to return the
	iterator to the fist element and compares each element
	to int x from the beginning of the vector to the end.
	To return the iterator position, the iterator subtracts
	the beginning element which is 0 and returns itself.
	Else, the iterator return -1.
****************************************************************/

int linearSearch( const vector<int>& inputVec, int x) {

vector<int>::const_iterator itrate; // Declares iterator

itrate = find(inputVec.begin(), inputVec.end(), x );//uses find to compare x in vector.
					//from beginning to end of vector.

if(itrate != inputVec.end()) // if not end of vector

return itrate - inputVec.begin();//return iterator position subtracted by beginning (0)

else return -1;

}


/****************************************************************

   FUNCTION:   int binarySearch( const vector<int>& inputVec, int x

   ARGUMENTS:  const vector<int>& inputVec, int x

   RETURNS:    integer,  itBounds.first - inputVec.begin(), or -1

   NOTES: This function declears a pair of iterators called itBounds.
	Next it uses the iterators to binary search the vector called
	inputVec by implementing the function called equal_range.
	Equal range sends two iterators to locate the x position.
	Once found, the second iterator iterates ascendingly to
	find the next greater value then stores the range of iterations
	between the two. If the iterators do not find the x value
	they will iterate to the end and therefore equal the last
	element indicating nothing was found and returning -1.
****************************************************************/
int binarySearch( const vector<int>& inputVec, int x) {

pair<vector<int>::const_iterator, vector<int>::const_iterator> itBounds;

itBounds = equal_range(inputVec.begin(), inputVec.end(), x);// using two iterators.


if(itBounds.first == itBounds.second)// if x element is not found both iterators
					// will equal each other.

return -1;

else return itBounds.first - inputVec.begin();

}

/****************************************************************

   FUNCTION: int search( const vector<int>& inputVec, const vector<int>& searchVec,

int (*p)( const vector<int>&, int))


   ARGUMENTS:  const vector<int>& inputVec, const vector<int>& searchVec,

int (*p)( const vector<int>&, int

   RETURNS:    integer, count

   NOTES:   This function uses a function pointer (*p) to point
	and direct the input to the correct function reference.
	This references the linear and binary function
	implementaions and creates a count of the number of
	searches in the inputVec and searchVec. This increments
	the count 1 time every time this functions are used.
****************************************************************/
int search( const vector<int>& inputVec, const vector<int>& searchVec,

int (*p)( const vector<int>&, int)) {

int count = 0;

for(int i = 0; i < searchVec.size(); i++){
if(p(inputVec, searchVec[i]) >= 0)// if the index of the search vector
				// in the input vector is greater than
				// zero, increment 1.

count++;		//store and return count.

}
return count; 

}


/****************************************************************

   FUNCTION:   void sortVector (vector<int>& inputVec)

   ARGUMENTS:  vector<int>& inputVec

   RETURNS:    Void, Nothing

   NOTES:      This function simply sorts the vector inputVec
		from beginning to end in ascening order.
****************************************************************/
void sortVector (vector<int>& inputVec) {


sort(inputVec.begin(), inputVec.end());

}

/****************************************************************

   FUNCTION:   void printStat (int totalSucCnt, int vec_size

   ARGUMENTS:  int totalSucCnt, int vec_size

   RETURNS:    Void, nothing

   NOTES:      This function takes the total success count and
		divides it by the Vector size then multiplies
		it by 100 to get the percent of successful
		searches. Then it outputs the percentage.
****************************************************************/
void printStat (int totalSucCnt, int vec_size) {

float r;
r = ((float)totalSucCnt / (float)vec_size) * 100;
cout <<"The percentage of successful searches is "<< fixed << setprecision(2) << r << "%" << endl;;

}


/****************************************************************

FUNCTION:   void print_vec( const vector<int>& vec )

ARGUMENTS:   const vector<int>& vec

RETURNS:    void , nothing.

NOTES:    This function creates a print method and iterates
        through the vector vec. The iterator is a constant
        and declares "iterate" as it's object. A "for" loop is then
        implemented and assigns "iterate" to begin the iteration
        function through the vector object. If the iteration
        hasnt reached the end, and it keeps iterating the print
        "iterate" pointer. As "iterate" iterates, the setw sets the width
        of each element 5 spaces. If  elements are printed
        a new line is added for the next 12 elements and
        the counter is set to 0 again.
****************************************************************/

void print_vec( const vector<int>& vec ){

     int count = 0;
     vector<int>::const_iterator iterate;

     for(iterate = vec.begin(); iterate != vec.end(); iterate++ ){
     cout << setw(5) << *iterate << " ";

     count++;

     if(count == 12){

     cout << endl;
     count = 0;

    	 }
     }
     cout << endl;

}





int main() {

vector<int> inputVec(DATA_SIZE);

vector<int> searchVec(SEARCH_SIZE);

genRndNums(inputVec, DATA_SEED);

genRndNums(searchVec, SEARCH_SEED);

cout << "----- Data source: " << inputVec.size() << " randomly generated numbers ------" << endl;

print_vec( inputVec );

cout << "----- " << searchVec.size() << " random numbers to be searched -------" << endl;

print_vec( searchVec );

cout << "\nConducting linear search on unsorted data source ..." << endl;

int linear_search_count = search( inputVec, searchVec, linearSearch );

printStat ( linear_search_count, SEARCH_SIZE );


cout << "\nConducting binary search on unsorted data source ..." << endl;

int binary_search_count = search( inputVec, searchVec, binarySearch );


printStat ( binary_search_count, SEARCH_SIZE );

sortVector( inputVec );

cout << "\nConducting linear search on sorted data source ..." << endl;

linear_search_count = search( inputVec, searchVec, linearSearch );

printStat ( linear_search_count, SEARCH_SIZE );

cout << "\nConducting binary search on sorted data source ..." << endl;

binary_search_count = search( inputVec, searchVec, binarySearch );

printStat ( binary_search_count, SEARCH_SIZE );


cout << endl;

return 0;

}

