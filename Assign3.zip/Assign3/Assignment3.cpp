/*
Assignment 3
CSCI 340
Name: Lukus Hendrix
ZID: z1761354
SECTION: 1
Due Date: 2/17/2017
T.A: Jyostna Ankam

FUNCTION:  This program implements an algorithm called the Sieve of Eratosthenes.
	Using a range between a set of lower and upper intereger values, the user is
	required to input the starting and ending value. The sieve algorithm
	calculates the total number of prime intergers and prints them onto
	the screen. After the calculation is finished, the program will
	ask the user if he or she would like to continue to re-loop the
	program again.

INPUT:     The input is asked from the user. The input is the range between
	lower and upper integer values. For example, the user can type
	1 100 for 1 through 100.

OUTPUT:   The output displays all of the prime integers it calculated amd
	also print the total number of prime numbers.
*/


#include<iostream>
#include<set>
#include<algorithm>
#include <iomanip>
#include<string>
using namespace std;

const int ITEM_W = 6;
int NO_ITEMS = 0;



/****************************************************************

   FUNCTION:   void sieve( set<int>& s, const int lower, const int upper)

   ARGUMENTS:  set<int>& s, const int lower, const int upper

   RETURNS:    Void, Nothing

   NOTES:      This function uses the set container to iterate through
	a sorted sequence of numbers. It first starts with a "for" loop
	and initiates the integer "i" to the "lower" value the user
	has input. Then it is compared to the user's input of the
	"upper" value. If it is less or equal, integers are inserted
	one by one until the upper value is reached. After that,
	another "for"loop is called and assigns the integer 2 to
	the variable k. If k is less or = to the upper value,
	a nested "for" loop is then called. The nested "for" loop
	then uses the iterator to start from the beginning of the
	set, using  a modulus to check to see if each integer in
	the set is divisible by 2 of the previous "for" loop. The only
	number allowed divisible by 2 is 2 which is "k" itself.
	The s.erase(it) is then implimented, erasing every number
	that is divisible by 2. The integer NO_ITEMS is then
	assigned to the iterator's value.
****************************************************************/

void sieve( set<int>& s, const int lower, const int upper) {

	set<int>::iterator it; // Initialize iterator


	for(int i = lower; i <= upper; i++) // creates the range of numbers by insertion between upper and lower input values.
		s.insert(i);



	for(int k = 2; k <= upper; k++){ //creates the integer 2 for every number in the set.
       		for(it = s.begin(); it != s.end(); it++ )

		if(*it % k == 0 && *it != k)// checks to see if each number in the set is divisible by "k" which is 2.
		s.erase(it); // erases each number divisible by 2 that is not 2 itself.
		NO_ITEMS = *it; // "*it" contains the amount of primes and is stored into NO_ITEMS.

	}

}

/****************************************************************

   FUNCTION:   void print_primes( const set<int>& s, const int lower, const int upper)

   ARGUMENTS:  const set<int>& s, const int lower, const int upper

   RETURNS:    Void, Nothing

   NOTES:      This function initializes a counter to 0 and then
	 initializes a set constant iterator called "it." Then
	 uses a "for" loop to iterate from the baginning to end
	of the set called s. Then the iterator of set s is then
	printed with a width size of 6. The counter then increments
	for each element. If the counter is equal to 8, a new
	line is created and the counter get initialized back to 0.
	This prints 8 elements in each row.

****************************************************************/

void print_primes( const set<int>& s, const int lower, const int upper) {

 /*counts the elements being printed */
int counter = 0;

set<int>:: const_iterator it;/*Declares "it" as the iterator object */

	for (it = s.begin(); it != s.end(); it++){// Iterates from beginning until the end of the set.
	cout << setw(ITEM_W) << *it << " ";  //This sets the width to 6, ITEM_W is initialized to 6 and prints the iterator.

        counter++; // Increments the counter 1 for every element.

                if(counter == 8){ /*if counter is equal to 8 then new line */
        		cout << endl;
			counter = 0; /*Then reset counter */
	       }
	}
}

/****************************************************************

   FUNCTION:   void run_game(set<int>& s)

   ARGUMENTS:  set<int>& s

   RETURNS:    Void, Nothing

   NOTES:      This function assigns variables upper and lower to
	integers. Then initailizes a string "yn" to "YES." This
	functions carries out a while loop to keep track of
	the user's input. While the user types yes or y the program
	will continue. A cout statement is then called to ask the
	user to enter a lower and upper bound. Between the lower
	and upper bound is the range of the set s. If the lower bound
	is a greater value than the upper bound, the function
	will give the user an error and tell him or her to input
	a lower value first. The sieve function is then called.
	If the lower bound is less than the upper bound it
	prints the number of counted primes.  Then it calls the
	print_primes function. It then asks the user if they want
	to continue and loops back through the function if the
	user reply yes or y. Capital letters don't matter because
	the transform function is called to make everything uppercase.
	Transform takes the string yn and converts each letter into
	a capital from the beginning to the end. The clear function is
	then implimented and clears the set for the next loop.

******************************************************************/

void run_game(set<int>& s) {

int lower;
int upper;


string yn  =  "YES" ;

while(yn == "YES" || yn == "Y") // Let's the user select yes or y
{
	cout <<"Please input lower bound and upper bound and hit enter (e.g. 10 100): " << endl; 
	cin >> lower >> upper;



	if(lower >= upper)
	{
	cerr << "Your lower bound "<< lower << " is greater than you upper bound "<< upper<< ".\n" 
	<<"The upper bound needs to exeed the lower bound. Please enter the lower bound in first if you continue. "<< endl ;
	}

sieve( s, lower,  upper);// Calls sieve function

	if(lower < upper)
	cout << "\nThere are "<< NO_ITEMS <<" prime numbers between "<<lower<<" and "<<upper<< ":\n";

print_primes(  s, lower,  upper); // calls print funtions


	cout << "\nDo you want to continue or not? Please answer yes or no and hit enter:" << endl;

	cin >> yn; // takes input and store it into string yn
		transform(yn.begin(), yn.end(),yn.begin(), ::toupper); // Converts the string yn to upper case.

	s.clear(); // clears set
}


}


int main() {
    set<int> s;
    run_game(s);
    return 0;
}




