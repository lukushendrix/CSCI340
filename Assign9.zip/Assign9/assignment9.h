/*
Assignment 9
CSCI 340
Name: Lukus Hendrix
ZID: z1761354
SECTION: 1
Due Date: 4/29/2017
T.A: Jyostna Ankam

FUNCTION:  This is the header file that creates the class graph.
*/

#ifndef ASSIGNMENT9_H
#define ASSIGNMENT9_H
#include <vector>
#include <list>

class graph {
    private:
        int size;
        std::vector< std::list<int> > adj_list;
        std::vector< char > labels;
        void depth_first( int );
    public:
        graph( const char* filename );
        ~graph();
        int get_size() const;
        void traverse( ) ;
        void print ( ) const;
};

#endif 
