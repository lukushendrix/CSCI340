/*
Assignment 9
CSCI 340
Name: Lukus Hendrix
ZID: z1761354
SECTION: 1
Due Date: 4/29/2017
T.A: Jyostna Ankam

FUNCTION:  This program implements different graph algorithms of simple
	graphs. These graphs are implemented using the adjacency list
	input on a text file. The program loops through the adjacency
	list and finds which values corresponds to what labels.

INPUT:     The input is a text file called assignment9input.txt. It has
	corresponding 1's and 0's to match with the labels A - G.

OUTPUT:   The output displays the corresponding adjacency matrix with
	the letters associated with it. The output also displays a
	depth first search traversal in associated order.
*/


#include <iostream>
#include <fstream>
#include <vector>
#include <list>
#include <algorithm>
#include "assignment9.h"
using namespace std;


// Global Variables
bool *vsd = NULL;
vector<int> trav;
vector<pair<int,int>> edges;


/****************************************************************

   FUNCTION:  graph :: graph ( const char* filename )

   ARGUMENTS:  const char* filename

   RETURNS:    class constructor.

   NOTES:      This function is the constructor that reads from
	the filename selected. I uses the input file stream to
	read the file, while not end of file read in the size
	and resize the labels and adjacency list to the current
	read in size. It then uses a for loop to index through
	each label storing inside variable labels. It then uses
	two additional for loops to store the columns index i
	into temp and store the rows intex j into check. For each
	letter in the column it checks the row and counts which
	1 is associated with what letter. If check equals 1, it
	puches the 1 onto the back of the adjacency list.

****************************************************************/

graph :: graph ( const char* filename )
{

ifstream read(filename);

	while(!read.eof())
	{
	read >> size;
	labels.resize(size) ;
	adj_list.resize(size);

		for(int i = 0; i < size; i++)
		read >> labels[i];
		char temp;
		int check;

			for(int i = 0; i < size; i++){
			  read >> temp;

			for(int j = 0; j < size; j++){
				read >> check;

			if(check == 1 ){
				adj_list[i].push_back(j);
				}
			}
		}
	}
	read.close();

}



/****************************************************************

   FUNCTION:  graph :: ~graph()

   ARGUMENTS:  Nothing

   RETURNS:    class destructor.

   NOTES:      This function clears the memory of thr adjacency
	list and labels. It also sets the size back to 0.

****************************************************************/

graph :: ~graph()
{

 adj_list.clear();
 labels.clear();
 size = 0;
}

/****************************************************************

   FUNCTION:  int graph::get_size() const

   ARGUMENTS:  Nothing, constant

   RETURNS:    integer

   NOTES:      This function uses the get_size method to simpley
	return the size.

****************************************************************/

int graph::get_size() const
{
	return size;
}

/****************************************************************

   FUNCTION:  void graph :: depth_first ( int v )

   ARGUMENTS:  int v

   RETURNS:   void, nothing

   NOTES:    This function uses the depth first algorithm and
	calls the traverse and recursivly calls itself. It uses
	a for loop and uses auto to easily declare the iterator
	it to the vector type. The loop iterates through the
	beginning to end of the adjacency list for the if statement.
	vsd is short for visited. If the vertices being visited
	equals to false, otherwords, if the vertice hasn't been visited
	then push back the location of the iterator in the
	traversal. Then uses pair to push back the edges v and it.
	If the visited point equals true, then it recursivly
	calls the depth first funtion with the iterator position.
****************************************************************/

void graph :: depth_first ( int v )
{


  for(auto it = adj_list[v].begin(); it != adj_list[v].end(); ++it)
	{
	if(vsd[*it] == false)
		{
		trav.push_back(*it);
		edges.push_back(pair<int, int>(v, *it));
		vsd[*it] = true;
		depth_first(*it);
		}
	}
}

/****************************************************************

   FUNCTION:  void graph :: traverse()

   ARGUMENTS:  Nothing

   RETURNS:    Void, nothing

   NOTES:      This is the traverse function and is used to traverse
	a graph and invoke the depth first method. It is also used to
	display the the traverse result. It starts off by creating a
	new boolian variable of size that is assigned to vsd which
	is an acronym for visited. It uses a for loop to make the
	size of the graph visited to be false. Then prints the
	traverses of the graph which uses a for loop to initiate
	vsd as true and pushes back the traversal of the indexed
	for loop. It also uses the index inside the depth fist
	functions parameter. It then uses an iterator from the
	beginning to the end of the traverse vector to display
	the labels. It also uses a iterator to display the comma's
	and the integer pair stored in the vector edges. Lastly
	It deletes the vsd bool. 

****************************************************************/

void graph::traverse()
{
vsd = new bool[size];

	for(int i = 0; i < size; i++)
		vsd[i] = false;

cout <<'\n'<< '\n'<<"----------Traverse of graph----------" << endl;

for (int i = 0; i < size; i++)
{
	if(vsd[i] == false)
	{
		vsd[i] = true;
		trav.push_back(i);
		depth_first(i);
	}
}

	for(auto it = trav.begin(); it != trav.end(); ++it)
	cout << labels[*it] << " ";

	cout << endl;

	for(auto it = edges.begin(); it != edges.end(); ++it)
	cout << "(" << labels[it->first] << ", " << labels[it-> second] << ")";

	cout << endl;

	cout <<"-----------End of Traverse-----------"<< endl;
	cout<<'\n';
	delete vsd;
}

/****************************************************************

   FUNCTION:  void graph :: print() const

   ARGUMENTS:  Nothing, const

   RETURNS:    void, nothing

   NOTES:      This function prints the number of vertices as well
	as the corresponding vertices with the adjacency list
	alphabetically. It uses a list constant iterator to loop
	through the size and uses another iterator to loop through
	adjacency list and prints it out.

****************************************************************/

void graph :: print() const
{

cout <<'\n' << "Number of Vertices " << size<< endl;

cout << "-------Graph---------"<< endl;
list<int>::const_iterator it;
for(int i = 0; i < size; i++)
{
	cout << endl<< labels[i] << ": ";

	for(it = adj_list[i].begin(); it != adj_list[i].end(); it++)
		cout << labels[*it]<< ", ";
}
cout << endl;
cout << "---------End of Graph -----------"<< endl;



}







#define ASSIGNMENT9_TEST
#ifdef 	ASSIGNMENT9_TEST

int main(int argc, char** argv) {
    if ( argc < 2 ) {
        cerr << "args: input-file-name\n";
        return 1;
    }

    graph g(argv[1]);

    g.print();

    g.traverse();

    return 0;
}

#endif
