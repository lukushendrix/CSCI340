
/*
Assignment 1
Name: Lukus Hendrix
ZID: z1761354
SECTION: 1
Due Date: 1/31/2017
T.A: Jyostna Ankam

  FUNCTION:  This program uses a true or false bool to iterate and compare
	a constant integer in a linear search. This program also uses a bool
	to compare a constant integer in a binary search. The last funtion
	implemented is a print method to output an accurate width between
	integers.

   INPUT:     The input has been provided in the inputVec as DATA_SIZE which
		is defined as 100 random number.

   OUTPUT:   Two lists of 66 and 50 random numbers that get searched and
		avereges out the comparisons of each.

*/

#include<iostream>
#include<vector>
#include <algorithm>
#include <iomanip>
using namespace std;

const int DATA_RANGE = 100;
const int DATA_SIZE = 100;
const int DATA_SEED = 7;
const int SEARCH_SEED = 9;
const int ITEM_W = 6;


/****************************************************************
FUNCTION: bool linear_search(const vector<int>& inputVec, const int x, int& comparisons)


ARGUMENTS: The linear search has 3 arguments, 1st being the inputVec which
	is the vector to be searched, the 2nd is x which is the variable to
	be found, and the 3rd is the comparisons which is the counter to
	comparisons.

RETURNS:    bool, either true or false.

NOTES:	  This function creates a vector called inputVec, then creates a
                constant integer x and a integer reference called comparisons.
                An iterator is then created called "it" and loops through the
                beginning to end of the vector called inputVec. If the search
                finds x then it returns true if not it returns false.
                The integer comparisons stores the number of comparisons.
******************************************************************/

bool linear_search(const vector<int>& inputVec, const int x, int& comparisons) 

{
vector<int>::const_iterator it ; /*assigns it to the constant vector iterator */
comparisons = 0; /* comparison counter */

for(it = inputVec.begin(); it != inputVec.end(); it++) /*Iterate through the */
{				 /* vector in linear form until the end null */
comparisons++; /* store each iteration of comparisons*/
 if(x == *it)/*if x equals the reference of the iterator then return true*/

return true;
 }

return false; /* else return false*/
}

/****************************************************************
FUNCTION: bool binary_search(const vector<int>& inputVec, const int x, int& comparisons)

ARGUMENTS:  1st argument is const vector<int>& inputVec which is the vector
	to be searched. The 2nd argument is  const int x which is the variable
	to be found, and the 3rd argument is int& comparisons which stores the
	comparison count.

RETURNS:	This functio returns a bool, either true or false.

NOTES:      This function creates integer variables of first, last and
		mid of the vector. The first and mid are initialized to 0 and
		the last is initiated to the size of the vector minus 1 for
		the null. This function calls a while loop to loop through
		the first and last element of the vector. The comparisons
		argument then stores each comparison. This mid variable then
		initializes itself to the sum of the first and last variable
		and divides by 2 to be the center element. If the searched
		variable is equal to the mid variable it will return true,
		or else if the searched variable x is less then the mid then
		last is initialized to mid -1 and repaets the division again
		unitl the variable is found. If variable x is greater than mid
		then the first variable gets initialized is mid +1 which then
		divides the vector in half again from first "mid" to last.
		This repeats until variable is or isnt found.
****************************************************************/
bool binary_search(const vector<int>& inputVec, const int x, int& comparisons) {

int first = 0;
int last = inputVec.size() -1; /* last element in vector */
int mid = 0;
comparisons = 0; /* comparison count stored */
while(first <= last) /* loop until bool true or false is reached */
{
	comparisons++; /* iteration comparison count */

		mid = (first + last) / 2; /* Divides the vector in half */
	if(x == inputVec[mid]) /*if searched variable x is equal to midpoint */
 return true;			/* then true */
	else if(x < inputVec[mid] ) /* if x is less than midpoint */
		last = mid -1;		/* initializes mid to last - 1 */
	else first = mid +1;	/* or else, assign mid to first +1 */

}

	return false;  /* return false if x cannot be found */
}



/****************************************************************

FUNCTION:   void print_vec( const vector<int>& vec )

ARGUMENTS:   const vector<int>& vec

RETURNS:    void , nothing.

NOTES:    This function creates a print method and iterates
	through the vector vec. The iterator is a constant
	and declares "it" as it's object. A for loop is then
	implemented and assigns "it" to begin the iteration
	function through the vector object. If the iteration
	hasnt reached the end, it keeps iterating the print
	"it" reference. As "it" iterates the setw sets the width
	of each element 6 spaces. If 10 elements are printed
	a new line is added for the next 10 elements and
	the counter is set to 0 again.
****************************************************************/
void print_vec( const vector<int>& vec ){

int counter = 0; /*counts the elements being printed */

vector<int>:: const_iterator it;/*Declares "it" as the iterator object */
for (it = vec.begin(); it != vec.end(); it++)/*Iterates from beginning until the end */
{

	cout << setw(ITEM_W) << *it << " "; /*Sets the width to 6, ITEM_W is initialized in include statement */

	counter++;

		if(counter == 10){ /*if counter is equal to 10 then new line */

	cout<< endl;
	counter = 0; /*Then reset counter */
}
	}
	cout << endl;  /* end line */

}


void average_comparisons(const vector<int>& inputVec, const vector<int>& searchVec, bool (*search)(const vector<int>&, const int, int&) ) {
    int i, comparison=0, sum=0, found = 0;
    bool res;
    for (i=0; i<(int)searchVec.size(); i++) {
        res = search( inputVec, searchVec[i], comparison );
        sum += comparison;
        if ( res )
           found++;
    }
    cout << found << " numbers are found. The average number of comparisons in each search: " << (double)sum/(double)searchVec.size() << endl << endl;
}

int random_number() {
    return rand()%DATA_RANGE+1;
}

int main () {

    // -------- create unique random numbers ------------------//
    vector<int> inputVec(DATA_SIZE);
    srand(DATA_SEED);
    generate(inputVec.begin(), inputVec.end(), random_number);
    sort(inputVec.begin(), inputVec.end());
    vector<int>::iterator it = unique(inputVec.begin(), inputVec.end());
    inputVec.resize( it - inputVec.begin() );
    random_shuffle( inputVec.begin(), inputVec.end() );

    cout << "------ Data source: " << inputVec.size() << " unique random numbers ------" << endl; 
    print_vec(inputVec);
    cout << endl;

    // -------- create random numbers to be searched ---------//
    vector<int> searchVec(DATA_SIZE/2);
    srand(SEARCH_SEED);
    generate(searchVec.begin(), searchVec.end(), random_number);

    cout << "------ " << searchVec.size() << " random numbers to be searched: ------" << endl;
    print_vec(searchVec);
    cout << endl;

    cout << "Linear search: ";
    average_comparisons(inputVec, searchVec, linear_search);
    cout << "Binary search: ";
    average_comparisons(inputVec, searchVec, binary_search);

    sort(inputVec.begin(), inputVec.end());
    cout << "------- numbers in data source are now sorted ---------" << endl << endl;
    cout << "Linear search: ";
    average_comparisons(inputVec, searchVec, linear_search);
    cout << "Binary search: ";
    average_comparisons(inputVec, searchVec, binary_search);

    return 0;

}



