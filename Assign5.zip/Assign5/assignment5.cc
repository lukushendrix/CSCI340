/*
Assignment 5
CSCI 340
Name: Lukus Hendrix
ZID: z1761354
SECTION: 1
Due Date: 03/10/2017
T.A: Jyostna Ankam

FUNCTION:  This program implements classes to represent a binary tree of
	integers, using a max size of 40.

INPUT:     This program uses a height of 6 and a size of 40 displaying the
	first 40 numbers.

OUTPUT:   The output displays 40 integers of each tree of traverse In Order,
	Pre-Oreder, and Post-Order.
*/

#include <iostream>
#include <iomanip>
#include <algorithm>
#include <vector>
#include "Assignment5.h"
using namespace std;

const int MAX_SIZE = 40;
const int MAX_COUNT = 40;
const int WIDTH = 5;
const int ROW_SIZE = 8;

int mcount = 0;
int rcount = 0;

void display(int d) {
    if ( mcount < MAX_COUNT ) {
        cout << setw(WIDTH) << d;
        mcount++;
        rcount++;
        if ( rcount == ROW_SIZE ) {
            cout << endl;
            rcount = 0;
        }
    }
}

/****************************************************************

   FUNCTION:   binTree::binTree()

   ARGUMENTS:  Nothing

   RETURNS:    class constructor.

   NOTES:      This function is the constructor that initializes
	the root to a null pointer.

****************************************************************/

    	binTree::binTree()
	{
	root = NULL;
	}

/****************************************************************

   FUNCTION:   void binTree::insert(int val)

   ARGUMENTS: int val

   RETURNS:    Nothing, Void

   NOTES:      This function uses the private insert function
	from the class binTree call itself along with root and
	the value being inserted.

****************************************************************/
	 void binTree:: insert( int val )
	{
	insert(root, val);

	}


/****************************************************************

   FUNCTION:  int  binTree::height() const

   ARGUMENTS:  Nothing

   RETURNS:    Int, integer

   NOTES:      This function sets the root into the height funtion
	and calls itself.
****************************************************************/

        int binTree::height() const
	{

	return height(root);
	}



/****************************************************************

   FUNCTION:   unsigned binTree:size() const

   ARGUMENTS:  Nothing

   RETURNS:    unsigned

   NOTES:      This function sets the root into the size funtion
        and calls itself.

****************************************************************/
        unsigned binTree::size() const
	{
	return size(root);
	}


/****************************************************************

   FUNCTION:   void binTree::inorder(void (*p)(int))

   ARGUMENTS:  void(*p)(int)

   RETURNS:    Void, Nothing

   NOTES:      This function sets the root and a function call to
	the pointer *p into the inorder funtion and calls itself.

****************************************************************/

        void  binTree::inorder( void(*p)(int) )
	{
	inorder(root, p);
	}


/****************************************************************

   FUNCTION:   void binTree::prorder(void (*pr)(int))

   ARGUMENTS:  void(*pr)(int)

   RETURNS:    Void, Nothing

   NOTES:      This function sets the root and a function call to
        the pointer *pr into the prorder funtion and calls itself.

****************************************************************/


        void binTree::preorder( void(*p)(int) )
	{
	preorder(root, p);
	}

/****************************************************************

   FUNCTION:   void binTree::postorder(void (*po)(int))

   ARGUMENTS:  void(*po)(int)

   RETURNS:    Void, Nothing

   NOTES:      This function sets the root and a function call to
        the pointer *po into the postorder funtion and calls itself.

****************************************************************/

        void  binTree::postorder( void(*p)(int) )
	{
	postorder(root, p);
	}

/****************************************************************

   FUNCTION:   void binTree::insert(Node* &ptr, int x)

   ARGUMENTS:  Node* &ptr, int x

   RETURNS:    Void, Nothing

   NOTES:      This function inserts a new Node if the pointer
	is equal to null. Otherwise , it initializes lheight to
	point to the left node and rheight to point to the right
	Node. If the right Node height is less than the left Node
	height then the insert funtion is called to point to the
	value inside of the right node. Otherwise, the insert
	function will point to the value of the left node.


****************************************************************/

void  binTree::insert(Node* &ptr, int x)
{
	int lheight = 0;
	int rheight = 0;

	if (ptr == NULL)

		ptr = new Node(x);

	else{

		lheight = height(ptr->left);
		rheight = height(ptr->right);

	if (rheight < lheight)
	{
		insert(ptr->right, x);
	}
	else
		insert(ptr->left, x);
	}
}

/****************************************************************

   FUNCTION:   int binTree::height(Node* ptr)const

   ARGUMENTS:  Node* ptr

   RETURNS:    int, Integer

   NOTES:      This function points the heght of the tree. If
	the ptr is equal to a null it returns -1.  Then it initializes
	the left hand lh to the height funtion that points to the
	left node and the right hand  side rh to point to the
	right node. If lh is greater than rh return the lh plus
	1 to include the root. Otherwise it returns the rh plus
	1 to include the root.

****************************************************************/

        int  binTree::height( Node* ptr) const
	{
	if(ptr == NULL)
	return -1;

	int lh = height(ptr-> left);
	int rh = height(ptr -> right);

		if(lh > rh)
		return	lh + 1;
	else
		return rh +1;

	}

/****************************************************************

   FUNCTION:   void binTree::size(Node* ptr) const

   ARGUMENTS:  Node* ptr

   RETURNS:    unsigned

   NOTES:      This function adds the size of the tree together.
	If the pointer is pointing at null then return 0.
	Otherwise, return 1 plus the size function pointing to
	both sizes of the left and right node together.

****************************************************************/

        unsigned int binTree::size( Node* ptr) const
	{
	if(ptr == NULL)
	return 0;

	else
	return 1 + size(ptr -> left) + size(ptr -> right);

	}


/****************************************************************

   FUNCTION:   void binTree::inorder(Node* r, void (*p)(int))

   ARGUMENTS:  Node* r, void(*p)(int)

   RETURNS:    Void, Nothing

   NOTES:      This function allows the nodes to print inorder.
	If the root node is not a null pointer then the inorder
	function is called to have to root point at the left node
	first. After the root points at the data inside the node
	 Then lastly the inorder funtion uses the root to point
	at the right node.
****************************************************************/

        void  binTree::inorder( Node* r, void(*p)(int ) )
	{
		if(r != nullptr)
		{
			inorder(r->left, p);
			p(r-> data);
			inorder(r->right, p);
		}

	}


/****************************************************************

   FUNCTION:   void binTree::inorder(Node* r, void (*p)(int))

   ARGUMENTS:  Node* r, void(*p)(int)

   RETURNS:    Void, Nothing

   NOTES:      This function allows the nodes to print preorder
        positioning. If the root node is not a null pointer then
	the p function is called to have the root point at the data
	inside the node first. Then the preorder function is called
	and the root points to the left node. Then the preorder
	is called again for the root to point at the right node
	recursivly.
****************************************************************/



        void  binTree::preorder( Node* r, void(*p)(int) )
	{
		if(r != nullptr)
		{
			p(r->data);
			preorder(r-> left, p);
			preorder(r->right, p) ;
		}
	}


/****************************************************************

   FUNCTION:   void binTree::postorder(Node* r, void (*p)(int))

   ARGUMENTS:  Node* r, void(*p)(int)

   RETURNS:    Void, Nothing

   NOTES:      This function allows the nodes to print postorder.
        If the root node is not a null pointer then the postorder
        function is called to so the root can point at the left
	node. Then the postorder function is called again so the
	root can point at the right node. After that , the pointer
	then points to the data inside the node.
****************************************************************/


void  binTree::postorder(Node* r, void(*p)(int))
{
	if (r != NULL)
	{
		postorder(r->left, p);
		postorder(r->right, p);
		p(r->data);
	}
}



#define BINTREE_MAIN
#ifdef BINTREE_MAIN
int main() {
    vector<int> v(MAX_SIZE);
    for (int i=1; i<MAX_SIZE; i++)
        v[i] = i;
    random_shuffle( v.begin(), v.end() );

    binTree bt;
    vector<int>::iterator it;
    for (it=v.begin(); it!=v.end(); it++)
        bt.insert( *it );

    cout << "Height: " << bt.height() << endl;
    cout << "Size: " << bt.size() << endl;
    cout << "In order traverse (displaying first " << MAX_COUNT << " numbers): " << endl;
    mcount = rcount = 0;
    bt.inorder( display );
    cout << "\n\nPre order traverse (displaying first " << MAX_COUNT << " numbers): " << endl;
    mcount = rcount = 0;
    bt.preorder( display );
    cout << "\n\nPost order traverse (displaying first " << MAX_COUNT << " numbers): " << endl;
    mcount = rcount = 0;
    bt.postorder( display );

    cout << endl;
    return 0;
}

#endif

