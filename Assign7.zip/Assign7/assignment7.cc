/*
Assignment 7
CSCI 340
Name: Lukus Hendrix
ZID: z1761354
SECTION: 1
Due Date: 04/06/2017
T.A: Jyostna Ankam

FUNCTION:  This program implements a heapsort technique that builds a
	heap structure. It first builds a heap structure with numbers
	and then it retrieves the integers in a certain order dempending
	on the heap and prints them out.

INPUT:     The input is selected from it's heap size of 50.

OUTPUT:   The output displays the current input numbers, and the minimum heap.
	Then it dispays the heap sort in ascending order. It then repeats this
	process with building a max heap and then displays the numbers in
	descending order.
*/



#include <iostream>
#include <iomanip>
#include <algorithm>

using namespace std;

const int ITEM_W = 5;
const int HEAP_SIZE = 50;

/****************************************************************

   FUNCTION:   void heapify( vector < int >& v, int heap_size, int r, bool
		(*compar)(int left, int right) )


   ARGUMENTS:   vector < int >& v, int heap_size, int r, bool
                (*compar)(int left, int right

   RETURNS:    Nothing, void

   NOTES:     This function heapifies the vector of random numbers.
	It compares two integers to the heap size 'left' and 'right.'
	Left is initiated as the left side of the tree by being
	assigned to 2*r. Right is initiated as the right side of
	the tree which is 2*r +1. The letter r is an integer refering
	to the root of the tree. A temparary variable is also assigned
	as an integer. If the left is less or equal to the heap size
	and while comparing the left vector with the root vector,
	this assigns the left integer to the temparary integer.
	otherwise the root is assigned to the temparary integer.
	If the right integer is less or equal to the heap size
	then it stores the right integer into temp. If the temparary
	integer does not equal the root it then swaps the temparary
	integer with the root. Then this function recursivly calls
	heapify again until the heap is finished.

****************************************************************/

void heapify( vector < int >& v, int heap_size, int r, bool
(*compar)(int left, int right) )
{
int left = 2*r ;
int right = 2*r +1;
int temp;

	if(left <= heap_size && compar(v[left], v[r]))
		temp = left;
	else
		temp = r;

	if(right <= heap_size && compar(v[right], v[temp]))
		temp = right;

	if(temp != r){
		swap (v[temp], v[r]);

	heapify(v, heap_size, temp, compar);
	}
}
/****************************************************************

   FUNCTION:   void build_heap ( vector < int >& v, int heap_size,
		bool (*compar)(int, int) )

   ARGUMENTS:   vector < int >& v, int heap_size,
		bool (*compar)(int, int

   RETURNS:    Nothing, Void.

   NOTES:      This function constructs a heap with heap size
	elements in the vector. This starts off by creating a for
	loop where integer i is assigned to the heap sizethen diveded
	by 2. If i is greater than 0 then it decrements i for
	the heapify function.

****************************************************************/
void build_heap ( vector < int >& v, int heap_size,
bool (*compar)(int, int) )
{

	for(int i = heap_size / 2; i > 0 ; i--)
	{
	heapify( v, heap_size, i, compar );
	}
}

/****************************************************************

   FUNCTION:  bool less_than ( int e1, int e2 )

   ARGUMENTS: int e1, int e2

   RETURNS:    bool, True or False

   NOTES:      This function compares two integers and returns
	true if e1 is less than e2. Or else is returns false.
	This function is used as a predicate in the build heap
	which allows minimum heap to be constructed.

****************************************************************/
bool less_than ( int e1, int e2 )
{
	if(e1 <= e2)
	return true;
	else
	return false;

}

/****************************************************************

   FUNCTION:  bool greater_than ( int e1, int e2 )

   ARGUMENTS: int e1, int e2

   RETURNS:    bool, True or False

   NOTES:      This function compares two integers and returns
        true if e1 is greater than e2. Or else is returns false.
        This function is used as a predicate in the build heap
        which allows a maximum heap to be constructed.

****************************************************************/

bool greater_than ( int e1, int e2 )
{


	if(e1 >= e2)
	return true;
	else
	return false;
}

/****************************************************************

   FUNCTION: int extract_heap ( vector < int >& v, int& heap_size, bool
		(*compar)(int, int) )

   ARGUMENTS: vector < int >& v, int& heap_size, bool
		(*compar)(int, int)

   RETURNS:    integer

   NOTES:      This function extracts the root of the heap stored
	in the vector 'v.' This fills the root with the last element
	of the current heap, updates the heap size and heapifies
	the root. This returns the old root value. The intger 'first'
	is assigned to the vectors first address position. Then
	the vector size gets assigned to the v[1] position.
	After that the integer 'first' gets assigned to the vectors
	heap size and the heap size is then decremented. The heapify
	function is then called and returns the 'integer' first.

****************************************************************/

int extract_heap ( vector < int >& v, int& heap_size, bool
(*compar)(int, int) )
{
	int first = v[1];
	v[1] = v[heap_size];

	v[heap_size] = first;
	heap_size--;
	heapify(v, heap_size, 1, compar);

	return  first;
}

/****************************************************************

   FUNCTION:  void heap_sort ( vector < int >& v, int heap_size,
		bool (*compar)(int, int) )

   ARGUMENTS:  vector < int >& v, int heap_size,
		bool (*compar)(int, int

   RETURNS:   Nothing, void

   NOTES:      This function implements the heap sort algorithm.
	This creates a 'for' loop that assigns the integer i to
	the heap size, if the integer i is greater than 1, it
	will decrement i. This loop will sort the heap by using
	the extract heap function that gets assigned to i.
	This will then use reverse to reapat the process in
	ascending order.
****************************************************************/

void heap_sort ( vector < int >& v, int heap_size,
bool (*compar)(int, int) )
{

	for(int i = heap_size; i > 1; i--)
	v[i] = extract_heap ( v, heap_size, compar);
	reverse(v.begin()+1, v.end());

}

/****************************************************************

   FUNCTION:  void print_vector ( vector < int >& v, int pos, int size )

   ARGUMENTS: vector < int >& v, int pos, int size 

   RETURNS:   Nothing, void.

   NOTES:      This function used for printing purposes. This funtion
	starts out by using a for loop to iterate through the vector
	size. Then it prints out the each digit 5 spaces from each
	other. If the loop prints 8 integers, it ends the line.
	It then repeats ending each line until the vector is completed.

****************************************************************/

void print_vector ( vector < int >& v, int pos, int size )
{


for(unsigned i = pos; i < v.size(); i++)
{
	cout << setw(ITEM_W) << v[i] << " ";



	if(i%8 == 0)
		{
		cout << endl;

		}

	}
	cout << endl;
}




int main(int argc, char** argv) {
    // ------- creating input vector --------------
    vector<int> v;
    v.push_back(-1000000);    // first element is fake
    for (int i=1; i<=HEAP_SIZE; i++)
        v.push_back( i );
    random_shuffle( v.begin()+1, v.begin()+HEAP_SIZE+1 );

    cout << "\nCurrent input numbers: " << endl;
    print_vector( v, 1, HEAP_SIZE );

    // ------- testing min heap ------------------
    cout << "\nBuilding a min heap..." << endl;
    build_heap(v, HEAP_SIZE, less_than);
    cout << "Min heap: " << endl;
    print_vector( v, 1, HEAP_SIZE );
    heap_sort( v, HEAP_SIZE, less_than);
    cout << "Heap sort result (in ascending order): " << endl;
    print_vector( v, 1, HEAP_SIZE );

    // ------- testing max heap ------------------
    cout << "\nBuilding a max heap..." << endl;
    build_heap(v, HEAP_SIZE, greater_than);
    cout << "Max heap: " << endl;
    print_vector( v, 1, HEAP_SIZE );
    heap_sort( v, HEAP_SIZE, greater_than);
    cout << "Heap sort result (in descending order): " << endl;
    print_vector( v, 1, HEAP_SIZE );

    return 0;
}

