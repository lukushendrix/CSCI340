/****************************************************************************
Assignment 4
CSCI 340
Name: Lukus Hendrix
ZID: z1761354
SECTION: 1
Due Date: 2/28/2017
T.A: Jyostna Ankam

FUNCTION:  This program impliments a stack using STL queues. It uses two queues
	to store and manipulate data. The Stack class is used to get the push()
	, pop(), empty(), size(), and top() methods.

INPUT:     The user is required to input an integer that pushes into either
	 queue 1 or queue 2.

OUTPUT:   For each integer pushed the output displayed the amount of elements
	in the queue and the value of every element that gets pushed in or
	out of the standing queue.
*****************************************************************************/



#include <iostream>
#include<algorithm>
#include<queue>
#include<stack>
#include <stdlib.h>
#include "Assignment4Head.h"
#include <string>
#include <iomanip>

using namespace std; 




/****************************************************************

   FUNCTION:   bool Stack::empty() const

   ARGUMENTS:  const

   RETURNS:    bool. true or false

   NOTES:     This function uses the stack class to get the empty
	function. Then uses a bool to declear empty as true or
	false to check if either queue 1 or queue 2 is empty.

****************************************************************/



bool Stack::empty() const {

	bool empty = q1.empty() && q2.empty();


}



/****************************************************************

   FUNCTION:  int Stack::size() const

   ARGUMENTS:  const

   RETURNS:    int, count

   NOTES:     Using the stack class, this function counts the size
	of queue 1 and queue 2. This simply adds there size to count
	 and returns count.

****************************************************************/



int Stack::size() const {

	int count = q1.size() + q2.size();
	return count;


}


/****************************************************************

   FUNCTION:  int Stack::top()

   ARGUMENTS:  none

   RETURNS:    queue, int,  either q1.back or q2.back

   NOTES:     Using the stack class, This this function returns
	either the back of q1 or q2. If q1 is not empty return
	the back of queue 1, otherwise if queue 2 is not emtpy
	return the back of queue 2. This funcion uses the back
	of either queue 1 or 2 to show where the top of the stack
	 is.

****************************************************************/



int Stack::top() {

	if( !q1.empty())

		return q1.back();

	else if(!q2.empty())

		return  q2.back();


}

/****************************************************************

   FUNCTION: void Stack::push(const int& val)

   ARGUMENTS:  const int& val

   RETURNS:    Void, Nothing

   NOTES:     This function uses stack class to get the push method
	using one constant integer reference called val. If queue
	1 is not empty this pushes the val integer into the stack
	of queue 1. Otherwise, if queue 1 is empty it pushes the
	new val element into queue 2.

****************************************************************/


void Stack::push(const int& val) {

	if(!q1.empty())
		q1.push(val);

	else
		q2.push(val);

}

/****************************************************************

   FUNCTION: void Stack::pop()

   ARGUMENTS:  None

   RETURNS:    Void, Nothing

   NOTES:     This function uses the Stack class to retrieve the
	pop method. Then it assigns queue 1 to the fullQ container
	assigns queue 2 to the emptyQ container. If queue 2 is not
	empty it assigns it to the fullQ container, otherwise it
	will assign it to the empty queue container. The fullQ
	points to the size function -1 for null.  A 'for' loop
	is then called assigns  i = 1 if i is less than size of q2
	it adds i + 1. The fullQ then points at the front of the
	queue and initializes it to an integer call front. The
	fullQ then points to the pop method.  The emptyQ then
	points and inserts the front integer into
	the push method. Then the fullQ points to the pop method
	to clear to the queue back to 0.

****************************************************************/

void Stack::pop() {
queue<int>* fullQ = &q1;
queue<int>* emptyQ = &q2;

	if(!q2.empty())
	fullQ = &q2;
	else
	emptyQ = &q2;

	fullQ -> size() -1;

	for(int i = 1; i < q2.size() ; i++ ){
		int front = fullQ -> front();
		fullQ -> pop();
		emptyQ -> push(front);

	}

		fullQ->pop();

}

int main() {
    Stack s;
    string op;
    int val = 0;

   cout << "operation -- size front end" << endl;
   cin >> op;
   while ( !cin.eof() ) {
        if ( op == "push" ) {
            cin >> val;
            s.push( val );
            cout << op << " " << val << "    -- ";
        }
 else if ( op == "pop" ) {
            s.pop();
            cout << op << "       -- ";
        }
        else {
            cerr << "Error input: " << op << endl;
            return 1;
        }
        cout << setw(3) << s.size() << setw(5) << s.top() << endl;
        cin >> op;
  }

    while ( !s.empty() )
        s.pop();
    cout << "End -- size of Stack is: " << s.size() << endl;

    return 0;
}


