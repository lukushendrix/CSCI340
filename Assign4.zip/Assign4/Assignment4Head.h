

/***********************************************************
# PROGRAM:    Assignment 4  Header file
# PROGRAMMER: Lukus Hendrix
# ZID:        Z1761354
# DATE DUE:   02/28/2017
# Section:    1
# CSCI 340

Function: This declares the class stack .
*************************************************************/


#ifndef ASSIGNMENT4HEAD_H
#define ASSIGNMENT4HEAD_H
#include <queue>

class Stack {
    private:
        std::queue<int> q1, q2;
    public:
        bool empty() const;
        int size() const;
        int top();
        void push(const int& val);
        void pop();
};

#endif

