/*
Assignment 8
CSCI 340
Name: Lukus Hendrix
ZID: z1761354
SECTION: 1
Due Date: 4/21/2017
T.A: Jyostna Ankam

FUNCTION: This program creates and implements a search to manage
	item inventory, using a hash table with linear probing.

INPUT:    The input from a text file called assignment8input.text is used.

A:AB1:IDs
A:AB3:name
A:CA0:keys
A:BA2:book
A:AC0:grades
A:AF3:comments
P:
S:AB3
S:BA2
S:AF4
S:AA2
D:AF3
D:GA4
D:FA3
D:BA3
D:AB3
D:AC0
P:
S:BA2
S:AB2
S:AD3
A:AC0:grades
A:GA0:year
A:BB0:graduation
D:AB1
P:
S:BA0
S:BB0


OUTPUT:   The output displays all of the hash table and marks each
	key and diplays where each key is found.
*/


#include <iostream>
#include <algorithm>
#include "assignment8.h"
#include <sstream>
#include <fstream>

using namespace std;

/****************************************************************

   FUNCTION:  HT :: HT ( int s=11 ) 

   ARGUMENTS:   int s=11

   RETURNS:    class constructor

   NOTES:      This function is the constructor that intitailizes
	the table size to s which is 11, item count to 0, and the
	Hash Table to the vector Entry of s.

****************************************************************/

HT :: HT ( int s=11 ) {


	 table_size = s;
	 item_count = 0;
	hTable = new vector<Entry> (s) ;

}

/****************************************************************

   FUNCTION:   HT :: ~HT ()

   ARGUMENTS:  none

   RETURNS:    class destructor.

   NOTES:      This function is the destructor that assigns
	the table size to 0, the item count to 0. and the Hash
	table to NULL.
****************************************************************/


HT :: ~HT () {

	 table_size = 0;
	 item_count = 0;

	hTable = NULL;
}

/****************************************************************

   FUNCTION:   int HT :: search ( const string& key )

   ARGUMENTS:  const string& key

   RETURNS:    integer

   NOTES:      This function loops through the hash table to
	search and find the correct key. If the key is found
	it returns the location of the key then breaks the
	loops, if not ,  the loop iterates through the rest of
	the table until it has went back to the begining and
	assigns the "for" loop iterator back to 0.

****************************************************************/

int HT :: search ( const string& key ) {


int hashVal = hashing(key);



	for(int i = hashVal; ;)
	{

		if(key == (*hTable)[i].key)
			return i;
		i++;

		if(i==table_size)
			 i=0;

		if(i==hashVal)
			 break;

	}
	return -1;
}


/****************************************************************

   FUNCTION:  bool HT :: insert ( const Entry& e )

   ARGUMENTS:  const Entry& e

   RETURNS:    bool, true or false

   NOTES:      This function runs through the table first checking
	if the table is full and if so it returns false. Then assigns
	the key entry which is the letter "e" from the search to a
	new key integer. This checks if the key exists in the hash
	table by checking if the search method returned -1. Otherwise,
	if the key is less then the table size it will loop though
	the hash table in search of either "---" or "+++". If
	"+++" or "---" if found it then assigns the entry of "e"
	to that location. The loop then breaks and the counter
	is incremented by 1.

****************************************************************/

bool HT :: insert ( const Entry& e ) {

	if( table_size == item_count){
		cout<< "Table is full";
		return false;
	}
int key = search(e.key);


	 if(key != -1){
	 	cout << "Error: Key Exists";
		return false;
		}
	 else{

	for(int i = key ; i < table_size; i++){
		if( (*hTable)[i].key == "---" ||( *hTable)[i].key  == "+++")
			{
			(*hTable)[i] = e;
			break;
			}

		}
	item_count++;

	return true;
	}
}

/****************************************************************

   FUNCTION:  bool HT::remove(const string& s)

   ARGUMENTS:  const string& s

   RETURNS:    bool, true or false

   NOTES:      This function is used to locate items with "+++".
	The search function is assigned to removePos. If the position
	is -1 it will return false and skip over the position.
	Otherwise, the Hash Table will use the search function to
	assign the key to "+++", decrement item count and return
	true.

****************************************************************/

bool HT::remove(const string& s) {

int removePos = search(s);
	if( removePos == -1)
		return false;
	else
		{
			(*hTable)[removePos].key = "+++";
			item_count-- ;
			return true;
		}


}

/****************************************************************

   FUNCTION:  void HT :: print ( )

   ARGUMENTS:  Nothing

   RETURNS:    Nothing, Void

   NOTES:      This function prints the size of the table and the
	entry keys associated with the different locations. While
	printing the entries to the table it also displays the
	keys description.

****************************************************************/

void HT :: print ( )
{
for(int i =0; i< table_size; i++)
{
	Entry e = (*hTable)[i];
	cout << "Item" << (i+1) << ": Keys =" << e.key<< ", Description: " << e.description << endl;
	}
}

/****************************************************************

   FUNCTION:   Entry* get_entry (const string& line)

   ARGUMENTS:  const string& line

   RETURNS:    e, entry

   NOTES:      This function is used to get the line of the entry.
	It uses a delimiter called sep to separate the entries.
	This function then takes the line of input and parses it
	to create a new entry.

****************************************************************/

Entry* get_entry (const string& line)
{
char sep = ':';
        stringstream ss(line);
        string key;
        getline(ss, key, sep);
        getline(ss, key, sep);
        string des;
         getline(ss, des, sep);



    Entry* e = new Entry();
        e->key = key;
        e->description = des;


     return e;


}

/****************************************************************

   FUNCTION:  string get_key (const string& line)

   ARGUMENTS: const string& line

   RETURNS:   string , key

   NOTES:      This function is used to get the string key and
	return it to main. It uses a delimiter called sep to
	seperate the string line from the key.

****************************************************************/

string get_key (const string& line)
{
char sep = ':';

        stringstream stm(line);
        string key;
        getline(stm, key, sep);
        getline(stm, key, sep);


        return key;

}



// key is in form of letter-letter-digit
// compute sum <-- ascii(pos1)+ascii(pos2)+ascii(pos3)
// compute sum%htable_size
int HT::hashing(const string& key) {
   return ((int)key[0] + (int)key[1] + (int)key[2])%table_size;
}

int main(int argc, char** argv ) {
    if ( argc < 2 ) {
        cerr << "argument: file-name\n";
        return 1;
    }

    HT ht;
    ifstream infile(argv[1], ios::in);
    string line;
    infile >> line;    
    while ( !infile.eof() ) {
        if ( line[0] == 'A' ) { 
            Entry* e = get_entry( line );
            ht.insert( *e );
            delete e;
        }
        else {
            string key = get_key(line);
            if ( line[0] == 'D' ) {
                cout << "Removing " << key << "...\n";
                bool removed = ht.remove( key );
                if ( removed )
                    cout << key << " is removed successfully...\n\n";
                else
                    cout << key << " does not exist, no key is removed...\n\n";
            }
            else if ( line[0] == 'S' ) {
                int found = ht.search( key );
                if ( found < 0 ) 
                    cout << key << " does not exit in the hash table ..." << endl << endl;
                else
                   cout << key << " is found at table position " << found << endl << endl;
            }
            else if ( line[0] == 'P' ) {
                cout << "\nDisplaying the table: " << endl;
                ht.print();
            }
            else
                cerr << "wrong input: " << line << endl;
        }
        infile >> line;
 
    }

    infile.close();
    return 0;
}
